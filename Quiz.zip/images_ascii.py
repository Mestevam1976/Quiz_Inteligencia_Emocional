import formatacao

texto = ('''
            +-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
            |Q|U|I|Z|:| |I|N|T|E|L|I|G|E|N|C|I|A| |E|M|O|C|I|O|N|A|L|
            +-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
''')

logo = formatacao.escolher_cor('yellow',texto)
